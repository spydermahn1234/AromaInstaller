# Android 10 Light Bootanimation

## What this module does? ##
This module brings you Android 10 Light Bootanimation for any android device.

(It may not work on Oppo Devices)

Spl. Thanks to Lord Vicky for helping me to make this module.

## Help ##
You can join our group if  you face any issue. Join the group here :- https://t.me/ModuleMagic

## Screenshots ##
Check out the font screenshots in below link :- https://t.me/ModuleMagic

## Testing devices ##
* [Tesing Device] OnePlus 3T Android Pie
* [Tesing Device] OnePlus 7 Pro Android Pie/Q
* [Tesing Device] Redmi Note 5 Poro Android Pie/Q

## Known bug ##
* none

## Changelog ##
* V1: Intial Build
