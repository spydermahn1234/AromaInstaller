# ViPER4Android 2.5.0.5 Black 'n Cheese Edition
This module enables ViPER4Android 2.5.0.5 Black 'n Cheese Edition, a themed ViPER4Android FX 2.5.0.5 installation presented by sonophilos. This also includes sonophilos' Lover of Sound resetprop, which, along with other audio quality focused props, will set media volume steps to 18 and disable the safe headset media volume warning.

## Compatibility
* Android Jellybean+
* Selinux enforcing
* All root solutions (requires init.d support if not using magisk or supersu. Try [Init.d Injector](https://forum.xda-developers.com/android/software-hacking/mod-universal-init-d-injector-wip-t3692105))

## Credits
* [ViPER's Audio](http://vipersaudio.com/blog/)
* [ViPER520](http://vipersaudio.com/blog/) @ XDA Developers
* [zhuhang](https://forum.xda-developers.com/showthread.php?t=2191223) @ XDA Developers
