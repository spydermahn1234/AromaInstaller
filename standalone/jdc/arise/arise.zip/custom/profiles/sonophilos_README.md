# ViPER FX 2.5.0.5 with AudiophileX and Lover of Sound profiles by guitardedhero and sonophilos
# Black 'n Cheese Edition presented by sonophilos

Lover of Sound profiles will not have their full intended effect unless Lock Effect Mode is set to Headset in ViPER's settings.
Lover of Sound profiles rely on ZhuHang's Razor Surround IRS which are available for free here: https://app.box.com/s/cyyegc75719589a89flg
Headphones profile uses +0 Bass, Speakers profile uses +50 Bass. Choose the ones for your sampling rate (shown in Driver Status).

Hope this helps.